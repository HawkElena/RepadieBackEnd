package repadie.restapi.Services;

import java.util.Map;

import repadie.restapi.Models.ProyectoPriorizadoModel;


public interface ProyPriorizadoService {
	public Map<String, ?> DMLCrearProyecto(ProyectoPriorizadoModel pProyPriorizado);
	
}
