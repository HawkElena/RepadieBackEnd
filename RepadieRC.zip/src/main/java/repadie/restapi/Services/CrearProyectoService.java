package repadie.restapi.Services;

import java.util.Map;

import repadie.restapi.Models.CrearProyectoModel;

public interface CrearProyectoService {
	public Map<String, ?> DMLCrearProyecto(CrearProyectoModel pCrearProyecto);
	
}
